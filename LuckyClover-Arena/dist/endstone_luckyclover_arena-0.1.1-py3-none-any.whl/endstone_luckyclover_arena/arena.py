from __future__ import annotations

import json
import shlex
from pathlib import Path
from typing import Any

from endstone.command import Command, CommandSender
from endstone.plugin import Plugin
from endstone.scoreboard import Criteria, DisplaySlot, ObjectiveSortOrder


COLOR = "\u00a7"


class LuckyCloverArena(Plugin):
    api_version = "0.11"
    prefix = "LuckyCloverArena"
    authors = ["Mell"]
    version = "0.1.1"
    description = "Manual arena match controller for LuckyClover PvP events."

    commands = {
        "lcarena": {
            "description": "Manage LuckyClover PvP arena matches.",
            "usages": ["/lcarena [args: message]"],
            "permissions": ["luckyclover_arena.command.admin"],
        }
    }

    permissions = {
        "luckyclover_arena.command.admin": {
            "description": "Allow managing LuckyClover arena matches.",
            "default": "op",
        }
    }

    def on_enable(self) -> None:
        self.save_default_config()
        self.reload_all()
        self._board_page = "current"
        self._board_tick = 0
        self._last_entries: dict[str, set[str]] = {}
        self._last_boards: dict[str, tuple[str, ...]] = {}
        self._last_display_objective = ""
        self._ensure_objectives()
        self._sidebar_task = self.server.scheduler.run_task(
            self, self._sidebar_loop, delay=20, period=self._sidebar_refresh_ticks()
        )
        self.logger.info("LuckyClover-Arena enabled.")

    def on_disable(self) -> None:
        self.save_state()
        if hasattr(self, "_sidebar_task"):
            self._sidebar_task.cancel()

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if command.name != "lcarena":
            return False
        args = self.normalize_args(args)
        if not args:
            self.send_help(sender)
            return True

        sub = args[0].lower()
        rest = args[1:]

        if sub == "reload":
            self.reload_all()
            self._ensure_objectives()
            sender.send_message(f"{COLOR}aLuckyClover-Arena reloaded.")
            return True
        if sub == "list":
            self.cmd_list(sender)
            return True
        if sub == "current":
            self.cmd_current(sender)
            return True
        if sub == "next":
            self.cmd_next(sender)
            return True
        if sub == "start":
            if not rest:
                sender.send_message(f"{COLOR}cUsage: /lcarena start <match_id>")
                return True
            self.start_match(sender, rest[0])
            return True
        if sub == "win":
            if not rest:
                sender.send_message(f"{COLOR}cUsage: /lcarena win <player> [points]")
                return True
            player = rest[0]
            points = self._parse_points(rest[1:], self.config.get("score_per_win", 1))
            self.add_score(player, points)
            self.state["last_winner"] = player
            self.state["finished_matches"].append(self.current_match_id())
            self.save_state()
            self.broadcast(f"{COLOR}6[PvP] {COLOR}e{player}{COLOR}a wins and gains {points} point(s).")
            if self.is_last_match():
                self.broadcast_final_scores()
            return True
        if sub == "score":
            if not rest:
                sender.send_message(f"{COLOR}cUsage: /lcarena score <player> [points]")
                return True
            player = rest[0]
            points = self._parse_points(rest[1:], self.config.get("score_per_manual_add", 1))
            self.add_score(player, points)
            sender.send_message(f"{COLOR}aAdded {points} point(s) to {player}.")
            return True
        if sub == "board":
            if not rest or rest[0].lower() not in {"on", "off"}:
                sender.send_message(f"{COLOR}cUsage: /lcarena board <on|off>")
                return True
            self.state["sidebar_enabled"] = rest[0].lower() == "on"
            self.save_state()
            sender.send_message(f"{COLOR}aSidebar is now {rest[0].lower()}.")
            return True
        if sub == "reset":
            self.state = self.default_state()
            self.save_state()
            self.clear_boards()
            sender.send_message(f"{COLOR}aArena scores and current match cleared.")
            return True

        self.send_help(sender)
        return True

    def normalize_args(self, args: list[str]) -> list[str]:
        if len(args) != 1:
            return args
        try:
            return shlex.split(args[0])
        except ValueError:
            return args[0].split()

    def reload_all(self) -> None:
        self.reload_config()
        self.state_path = Path(self.data_folder) / "state.json"
        self.state = self.load_state()

    def default_state(self) -> dict[str, Any]:
        return {
            "current_index": -1,
            "scores": {},
            "last_winner": "",
            "finished_matches": [],
            "sidebar_enabled": True,
        }

    def load_state(self) -> dict[str, Any]:
        if not self.state_path.exists():
            return self.default_state()
        try:
            with self.state_path.open("r", encoding="utf-8") as f:
                loaded = json.load(f)
        except (OSError, json.JSONDecodeError):
            self.logger.warning("state.json is invalid; using empty state.")
            return self.default_state()
        state = self.default_state()
        state.update(loaded)
        state["scores"] = {str(k): int(v) for k, v in state.get("scores", {}).items()}
        state["finished_matches"] = list(state.get("finished_matches", []))
        return state

    def save_state(self) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        with self.state_path.open("w", encoding="utf-8") as f:
            json.dump(self.state, f, ensure_ascii=False, indent=2)
            f.write("\n")

    def matches(self) -> list[dict[str, Any]]:
        return list(self.config.get("matches", []))

    def current_match(self) -> dict[str, Any] | None:
        index = int(self.state.get("current_index", -1))
        matches = self.matches()
        if index < 0 or index >= len(matches):
            return None
        return matches[index]

    def current_match_id(self) -> str:
        match = self.current_match()
        return str(match.get("id", "")) if match else ""

    def is_last_match(self) -> bool:
        matches = self.matches()
        current = int(self.state.get("current_index", -1))
        return bool(matches) and current == len(matches) - 1

    def cmd_list(self, sender: CommandSender) -> None:
        matches = self.matches()
        if not matches:
            sender.send_message(f"{COLOR}eNo matches configured.")
            return
        current = int(self.state.get("current_index", -1))
        sender.send_message(f"{COLOR}6Configured matches:")
        for idx, match in enumerate(matches):
            marker = f"{COLOR}a*" if idx == current else f"{COLOR}7-"
            sender.send_message(f"{marker} {match.get('id')} {COLOR}f{match.get('name', '')}")

    def cmd_current(self, sender: CommandSender) -> None:
        match = self.current_match()
        if not match:
            sender.send_message(f"{COLOR}eNo current match. Use /lcarena next.")
            return
        sender.send_message(f"{COLOR}6Current: {COLOR}f{match.get('id')} - {match.get('name', '')}")
        for side in match.get("sides", []):
            sender.send_message(
                f"{COLOR}b{side.get('name', 'Side')}: {COLOR}f{', '.join(side.get('players', []))}"
            )

    def cmd_next(self, sender: CommandSender) -> None:
        matches = self.matches()
        if not matches:
            sender.send_message(f"{COLOR}cNo matches configured.")
            return
        next_index = int(self.state.get("current_index", -1)) + 1
        if next_index >= len(matches):
            sender.send_message(f"{COLOR}eNo more matches configured.")
            return
        self.state["current_index"] = next_index
        self.save_state()
        self.teleport_match(matches[next_index])
        self.announce_match(matches[next_index])

    def start_match(self, sender: CommandSender, match_id: str) -> None:
        for idx, match in enumerate(self.matches()):
            if str(match.get("id")) == match_id:
                self.state["current_index"] = idx
                self.save_state()
                self.teleport_match(match)
                self.announce_match(match)
                return
        sender.send_message(f"{COLOR}cUnknown match id: {match_id}")

    def teleport_match(self, match: dict[str, Any]) -> None:
        for side in match.get("sides", []):
            players = list(side.get("players", []))
            commands = list(side.get("teleport_commands", []))
            for player in players:
                for template in commands:
                    command = self.format_command(template, player, match, side)
                    self.dispatch(command)
                    if self.config.get("announce_commands", True):
                        self.logger.info(f"Dispatched: {command}")

    def announce_match(self, match: dict[str, Any]) -> None:
        sides = []
        for side in match.get("sides", []):
            names = ", ".join(side.get("players", []))
            sides.append(f"{side.get('name', 'Side')}({names})")
        self.broadcast(
            f"{COLOR}6[PvP] {COLOR}aNext match: {COLOR}e{match.get('name', match.get('id'))}"
            f"{COLOR}7 - {COLOR}f{' vs '.join(sides)}"
        )

    def add_score(self, player: str, points: int) -> None:
        scores = self.state.setdefault("scores", {})
        scores[player] = int(scores.get(player, 0)) + points
        self.save_state()

    def format_command(
        self, template: str, player: str, match: dict[str, Any], side: dict[str, Any]
    ) -> str:
        escaped_player = player.replace("\\", "\\\\").replace('"', '\\"')
        return template.format(
            player=escaped_player,
            raw_player=player,
            match_id=match.get("id", ""),
            match_name=match.get("name", ""),
            side=side.get("name", ""),
        )

    def _parse_points(self, args: list[str], default: int) -> int:
        if not args:
            return int(default)
        try:
            return int(args[0])
        except ValueError:
            return int(default)

    def send_help(self, sender: CommandSender) -> None:
        sender.send_message(f"{COLOR}6LuckyClover-Arena commands:")
        sender.send_message(f"{COLOR}e/lcarena next {COLOR}7- teleport next configured match")
        sender.send_message(f"{COLOR}e/lcarena start <match_id> {COLOR}7- teleport a specific match")
        sender.send_message(f"{COLOR}e/lcarena win <player> [points] {COLOR}7- add winner score")
        sender.send_message(f"{COLOR}e/lcarena score <player> [points] {COLOR}7- add manual score")
        sender.send_message(f"{COLOR}e/lcarena list/current/reload/board/reset")

    def broadcast(self, message: str) -> None:
        self.server.broadcast_message(message)

    def _sidebar_refresh_ticks(self) -> int:
        sidebar = self.config.get("sidebar", {})
        return max(20, int(sidebar.get("refresh_ticks", 40)))

    def _ensure_objectives(self) -> None:
        sidebar = self.config.get("sidebar", {})
        self.get_or_create_objective(
            sidebar.get("objective_current", "lc_arena_cur"),
            sidebar.get("current_title", "LuckyClover PvP"),
        )
        self.get_or_create_objective(
            sidebar.get("objective_ranking", "lc_arena_rank"),
            sidebar.get("ranking_title", "PvP Ranking"),
        )
        if self.server.scoreboard is None:
            current = sidebar.get("objective_current", "lc_arena_cur")
            ranking = sidebar.get("objective_ranking", "lc_arena_rank")
            current_title = sidebar.get("current_title", "LuckyClover PvP")
            ranking_title = sidebar.get("ranking_title", "PvP Ranking")
            self.dispatch_scoreboard(
                f"scoreboard objectives add {current} dummy {self.quote_arg(str(current_title))}"
            )
            self.dispatch_scoreboard(
                f"scoreboard objectives add {ranking} dummy {self.quote_arg(str(ranking_title))}"
            )

    def _sidebar_loop(self) -> None:
        sidebar = self.config.get("sidebar", {})
        if not sidebar.get("enabled", True) or not self.state.get("sidebar_enabled", True):
            return
        self._board_tick += self._sidebar_refresh_ticks()
        rotate_ticks = max(20, int(sidebar.get("rotate_ticks", 160)))
        if self._board_tick >= rotate_ticks:
            self._board_tick = 0
            self._board_page = "ranking" if self._board_page == "current" else "current"
        if self._board_page == "current":
            self.show_current_board()
        else:
            self.show_ranking_board()

    def show_current_board(self) -> None:
        sidebar = self.config.get("sidebar", {})
        objective = sidebar.get("objective_current", "lc_arena_cur")
        match = self.current_match()
        lines = [f"{COLOR}6Current Match"]
        if match:
            lines.append(f"{COLOR}e{match.get('name', match.get('id', ''))}")
            for side in match.get("sides", []):
                lines.append(f"{COLOR}b{side.get('name', 'Side')}")
                for player in side.get("players", []):
                    lines.append(f"{COLOR}f{player}")
        else:
            lines.append(f"{COLOR}7Waiting")
            lines.append(f"{COLOR}f/lcarena next")
        winner = self.state.get("last_winner", "")
        if winner:
            lines.append(f"{COLOR}aLast: {winner}")
        self.write_board(objective, lines[:15])

    def show_ranking_board(self) -> None:
        sidebar = self.config.get("sidebar", {})
        objective = sidebar.get("objective_ranking", "lc_arena_rank")
        size = max(1, int(sidebar.get("ranking_size", 10)))
        scores = sorted(
            self.state.get("scores", {}).items(), key=lambda item: (-int(item[1]), item[0].lower())
        )
        if not scores:
            self.write_board(objective, [(f"{COLOR}7No scores yet", 0)])
            return
        entries = [(self.ranking_entry(index, player), int(score)) for index, (player, score) in enumerate(scores[:size], start=1)]
        self.write_board(objective, entries)

    def write_board(self, objective: str, lines: list[str] | list[tuple[str, int]]) -> None:
        entries_with_scores = self.normalize_board_lines(lines)
        signature = tuple(entries_with_scores)
        if (
            self._last_boards.get(objective) == signature
            and self._last_display_objective == objective
        ):
            return

        board_objective = self.recreate_objective(objective)
        if board_objective is None:
            self.write_board_with_commands(objective, lines)
            return

        entries: set[str] = set()
        for line, score in entries_with_scores:
            entry = self.unique_entry(line, entries)
            entries.add(entry)
            board_objective.get_score(entry).value = score
        board_objective.set_display(DisplaySlot.SIDE_BAR, ObjectiveSortOrder.DESCENDING)
        self._last_entries[objective] = entries
        self._last_boards[objective] = signature
        self._last_display_objective = objective

    def unique_entry(self, line: str, existing: set[str]) -> str:
        entry = line[:36]
        suffix_count = 0
        while entry in existing:
            suffix_count += 1
            suffix = COLOR + "r" * suffix_count
            entry = line[: max(0, 36 - len(suffix))] + suffix
        return entry

    def normalize_board_lines(self, lines: list[str] | list[tuple[str, int]]) -> list[tuple[str, int]]:
        if not lines:
            return []
        if isinstance(lines[0], tuple):
            return [(str(line), int(score)) for line, score in lines]  # type: ignore[misc]
        total = len(lines)
        return [(str(line), total - idx) for idx, line in enumerate(lines)]  # type: ignore[arg-type]

    def ranking_entry(self, index: int, player: str) -> str:
        prefix = f"{COLOR}e{index}. {COLOR}f"
        max_player_len = max(1, 36 - len(prefix))
        return prefix + player[:max_player_len]

    def clear_boards(self) -> None:
        for objective in list(self._last_entries):
            board_objective = self.find_objective(objective)
            if board_objective is not None:
                board_objective.unregister()
        self._last_entries = {}
        self._last_boards = {}
        self._last_display_objective = ""

    def write_board_with_commands(self, objective: str, lines: list[str]) -> None:
        entries_with_scores = self.normalize_board_lines(lines)
        old_entries = self._last_entries.get(objective, set())
        for entry in old_entries:
            self.dispatch_scoreboard(f"scoreboard players reset {self.quote_arg(entry)} {objective}")

        entries: set[str] = set()
        for line, score in entries_with_scores:
            entry = self.unique_entry(line, entries)
            entries.add(entry)
            self.dispatch_scoreboard(
                f"scoreboard players set {self.quote_arg(entry)} {objective} {score}"
            )
        self.dispatch_scoreboard(f"scoreboard objectives setdisplay sidebar {objective}")
        self._last_entries[objective] = entries
        self._last_boards[objective] = tuple(entries_with_scores)
        self._last_display_objective = objective

    def broadcast_final_scores(self) -> None:
        scores = sorted(
            self.state.get("scores", {}).items(), key=lambda item: (-int(item[1]), item[0].lower())
        )
        self.broadcast(f"{COLOR}6[PvP] {COLOR}a全部比赛已结束，最终积分如下：")
        if not scores:
            self.broadcast(f"{COLOR}7暂无积分。")
            return
        for index, (player, score) in enumerate(scores, start=1):
            self.broadcast(f"{COLOR}e{index}. {COLOR}f{player} {COLOR}7- {COLOR}a{score} 分")

    def get_or_create_objective(self, name: str, display_name: str):
        objective = self.find_objective(name)
        if objective is not None:
            objective.display_name = str(display_name)
            return objective
        scoreboard = self.server.scoreboard
        if scoreboard is None:
            return None
        return scoreboard.add_objective(str(name), Criteria.DUMMY, str(display_name))

    def recreate_objective(self, name: str):
        sidebar = self.config.get("sidebar", {})
        display_names = {
            sidebar.get("objective_current", "lc_arena_cur"): sidebar.get(
                "current_title", "LuckyClover PvP"
            ),
            sidebar.get("objective_ranking", "lc_arena_rank"): sidebar.get(
                "ranking_title", "PvP Ranking"
            ),
        }
        old = self.find_objective(name)
        if old is not None:
            old.unregister()
        return self.get_or_create_objective(name, str(display_names.get(name, name)))

    def find_objective(self, name: str):
        scoreboard = self.server.scoreboard
        if scoreboard is None:
            return None
        try:
            return scoreboard.get_objective(str(name))
        except Exception:
            return None

    def dispatch_scoreboard(self, command: str) -> None:
        self.dispatch(command)

    def dispatch(self, command: str) -> None:
        self.server.dispatch_command(self.server.command_sender, command)

    def quote_arg(self, value: str) -> str:
        return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'
